#include <iostream>

int main(int argc, char** argv) {
    std::cout << "Labwork1!\n";

    return 0;
}
