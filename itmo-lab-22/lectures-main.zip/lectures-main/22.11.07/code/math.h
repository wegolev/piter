#ifndef MATH_HEADER_H
#define MATH_HEADER_H

int add(int x, int y);

int increment(int x);



const static float PI = 3.14f;
const extern float Exp;
const int SomeValue = 239;
static float PI2 = 3.14f;
extern float Exp2;
//int SomeValue2 = 239; // error: multiple definition of `SomeValue2';
void PrintInfo();

#endif
