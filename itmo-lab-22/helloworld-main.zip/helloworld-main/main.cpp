#include <iostream>


int main(int argc, char** argv) {
    std::cout << "Hello world!\n";
    
    return 0;
}
