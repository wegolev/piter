#pragma once

namespace ArgumentParser {

class ArgParser {
    // Your Implementation here!
};

} // namespace ArgumentParser